// Global variables
var slides = [];
var currentIndex = 0;

// 1. Update Preview 
function updatePreview() {
    var text = document.getElementById("editor").value;
    parseSlides(text);
    showSlide();
}

// 2. Parse Markdown 
function parseSlides(mdText) {
    // Student forgot to handle empty input
    if (mdText == "") return; 
    

    slides = mdText.split("---");
    

    for (var i = 0; i < slides.length; i++) {
        // BUG: This replaces ALL # in the text, not just at the start
        slides[i] = slides[i].replace("# ", "<h1>") + "</h1>"; 
    }
}

// 3. Show Current Slide
function showSlide() {
    var previewArea = document.getElementById("preview-area");
    var presentArea = document.getElementById("present-area");
    
    if (previewArea) {
        previewArea.innerHTML = slides[currentIndex];
    } else if (presentArea) {
        presentArea.innerHTML = slides[currentIndex];
    }

    // Update Counter
    var counter = document.getElementById("slide-counter");
    if (counter) {
        // BUG: if slides is empty, this will say "1 / 0"
        counter.innerText = (currentIndex + 1) + " / " + slides.length;
    }

    // Disable buttons 
    var leftBtn = document.getElementById("btn-left");
    var rightBtn = document.getElementById("btn-right");
    
    if (leftBtn && rightBtn) {
        // BUG: Does not disable on initial load properly
        if (currentIndex == 0) {
            leftBtn.disabled = true;
        } else {
            leftBtn.disabled = false;
        }

        if (currentIndex == slides.length - 1) {
            rightBtn.disabled = true;
        } else {
            rightBtn.disabled = false;
        }
    }
}

// 4. Navigation
function goLeft() {
    if (currentIndex > 0) {
        currentIndex = currentIndex - 1;
        showSlide();
    }
}

function goRight() {
    if (currentIndex < slides.length - 1) {
        currentIndex = currentIndex + 1;
        showSlide();
    }
}

// 5. Save to LocalStorage
function saveData() {
    var text = document.getElementById("editor").value;
    localStorage.setItem("mySlidesData", text);
    alert("Saved successfully!");
}

// 6. Load for Presentation
function loadForPresentation() {
    var savedText = localStorage.getItem("mySlidesData");
    if (savedText != null) {
        parseSlides(savedText);
        currentIndex = 0;
        showSlide();
    }
}

// 7. Fullscreen Logic
function toggleFullScreen() {
    if (!document.fullscreenElement) {
        document.documentElement.requestFullscreen();
        document.getElementById("btn-full").innerText = "Exit Full Screen";
    } else {
        document.exitFullscreen();
  
    }
}

// 8. Keyboard Shortcuts 
document.onkeydown = function(event) {
    // Arrow keys
    if (event.key === "ArrowLeft") {
        goLeft();
    } else if (event.key === "ArrowRight") {
        goRight();
    }
    
    // F11 Key
    if (event.key === "F11") {
        toggleFullScreen(); 
    }

    // Ctrl + S
    if (event.ctrlKey && event.key === "s") {
        saveData();

    }
}

// Initialize Editor on load
window.onload = function() {
    var editor = document.getElementById("editor");
    if (editor) {
        var saved = localStorage.getItem("mySlidesData");
        if (saved) {
            editor.value = saved;
            parseSlides(saved);
            showSlide();
        }
    }
}